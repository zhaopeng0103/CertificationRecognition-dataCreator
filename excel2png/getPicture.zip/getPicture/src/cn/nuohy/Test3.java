package cn.nuohy;


import java.io.File;

import cn.nuohy.imgutil.PDFToImage;
import cn.nuohy.officeutil.OfficeToPDF;

/**
 * 使用  icepdf 进行转化
 * @author yangnuo
 * 创建时间：2017年3月16日
 */
public class Test3 {
	public static void main(String[] args) {
		//测试 pdf 生成 图片 （加水印）
		/*PDFToImage pdf = new PDFToImage();
		pdf.pdftoIamge(0.9f,"E:/BD2017-03-16001-XDL-0316-1.pdf", "C:/Users/admin/Desktop/ss/");*/
		
		//word 转 pdf
		OfficeToPDF wordToPDF = new OfficeToPDF();
		//wordToPDF.docToPdf(new File("E:/logback.docx"), new File("C:/Users/admin/Desktop/ss/logback.pdf"));
		
		String newpdfpath = "C:/Users/admin/Desktop/ss/interface.pdf";
		wordToPDF.docToPdf(new File("E:/interface.xlsx"), new File(newpdfpath));
		
		PDFToImage pdf = new PDFToImage();
		pdf.pdftoIamge(0.9f,newpdfpath, "C:/Users/admin/Desktop/ss/");
	}

}
