package cn.nuohy.officeutil;

import java.io.File;
import java.io.FilenameFilter;

import cn.nuohy.officeutil.OfficeToPDF.TestThread;

/**
 * word批量转化为pdf
 * @author yangnuo
 * 创建时间：2017年3月16日
 */
public class OfficesToPDF {
	
	/**
	 * @param dirs doc转换文件夹，批量转换
	 */
	public static void word2Pdf(String  dirs){
		 File dir = new File(dirs); 
		 File[] files = dir.listFiles(new WordFilenameFilter()); 
		   //遍历文件夹方式
		    if (files == null||files.length==0){
		    	throw new NullPointerException("该路径下没有office文件");
		    }
		    for (int i = 0; i < files.length; i++) { 
		            String strFileName = files[i].getAbsolutePath().toLowerCase(); 
		            TestThread t1 = new OfficeToPDF.TestThread();
		            //输入文件名
		           t1.setInputFile(new File(strFileName));
		            //获得"."前面的文件名并将其输入为PDF
		    		t1.setOutputFile(new File(strFileName.substring(0,strFileName.indexOf("."))+".pdf"));
		            t1.start();
		    }
	
    } 

	/**
	 * @param orgfileName 原始word文件名
	 * @param descFileName 生成pdf文件名
	 */
	public static void word2Pdf(String orgfileName, String descFileName) {
		if(!isWord(orgfileName)||descFileName==null){
			throw new IllegalArgumentException("原始word文件名不是word文档,或者descFileName为空");
		}
		TestThread t1 = new OfficeToPDF.TestThread();
		// 输入文件名
		t1.setInputFile(new File(orgfileName));
		// 获得"."前面的文件名并将其输入为PDF
		t1.setOutputFile(new File(descFileName.substring(0, descFileName
				.indexOf("."))
				+ ".pdf"));
		t1.start();
	}
	static class WordFilenameFilter implements FilenameFilter{
		@Override
		//只转换word文档
		public boolean accept(File dir, String name) {
			return isWord(name);
		}
		
	}
	/**
	 * @param name 文件名
	 * @return 判断是否为doc word文档
	 */
	private static boolean isWord(String name){
		return name.endsWith(".doc")||name.endsWith(".docx")||name.endsWith(".wps");
		//return true;
	}
	
}
